package com.tesler.ai.common

 /**
  * Shared utilities: starter interface.
  * TODO: implement and test this component before treating the feature as available.
  */
interface Logger {
    // Define a narrow, testable contract here as the feature is implemented.
}
