# Shared utilities

Small shared primitives; avoid making this a dumping ground for unrelated features.
