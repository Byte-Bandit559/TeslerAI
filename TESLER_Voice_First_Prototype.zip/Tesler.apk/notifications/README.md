# Notification integration

Notification-listener integration requires explicit user enablement in Android settings.
