package com.tesler.ai.notifications

 /**
  * Notification integration: starter interface.
  * TODO: implement and test this component before treating the feature as available.
  */
interface NotificationAction {
    // Define a narrow, testable contract here as the feature is implemented.
}
