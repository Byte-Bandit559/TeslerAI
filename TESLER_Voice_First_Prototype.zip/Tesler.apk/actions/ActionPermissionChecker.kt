package com.tesler.ai.actions

 /**
  * User-approved Android actions: starter interface.
  * TODO: implement and test this component before treating the feature as available.
  */
interface ActionPermissionChecker {
    // Define a narrow, testable contract here as the feature is implemented.
}
