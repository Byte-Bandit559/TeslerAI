# User-approved Android actions

Typed action requests and permission/confirmation boundaries; actions must use supported Android APIs.
