# TESLER voice-first prototype

## Implemented in this source revision
- Large tap-to-talk microphone control using Android `SpeechRecognizer`; requests offline recognition when the installed recognizer supports it.
- Spoken replies using the phone's installed Android text-to-speech voice. Voice/language quality and offline availability depend on the phone's installed speech services and downloaded voice data.
- Typed input remains available as a fallback.
- Local chat transcript and local 21-day rolling memory. Imported text excerpts are stored as searchable local memory; importing chats does not train model weights.
- Basic spoken command routing: open matching installed apps, open Android/Wi-Fi/Bluetooth/battery/accessibility settings, report selected device stats, open music apps, launch a web search, recall recent memories, and request typing into a focused field.
- Optional Accessibility Service for typing into a focused editable field. The user must enable it manually in Android Accessibility settings; it does not silently grant itself access.
- Device overview: Android release/API, manufacturer/model, reported RAM, battery percentage, and app-managed files/cache usage.
- Plugin manifest loading and proposal-only groundwork remain separate modules; arbitrary plugin code is not executed.

## Important boundaries
- This is not yet a general-purpose AI brain. There are no bundled model weights or inference runtime, so open-ended conversation is handled by small local rules, not an LLM.
- `EXTRA_PREFER_OFFLINE` is a preference sent to Android speech recognition, not a guarantee. Offline recognition works only if the device's speech provider and language pack support it. Otherwise the provider may require a network or fail.
- TESLER uses a generic installed TTS voice. It does not clone or biometrically learn the user's voice. Conversation transcripts are retained locally to establish memory groundwork; actual personality adaptation requires a connected model and a deliberate profile/retrieval layer.
- App launching and Settings shortcuts are constrained by Android. It cannot freely read or change protected system settings, bypass lock screens, or perform arbitrary actions in other apps.
- Voice input is tap-to-talk in this revision; no always-listening wake-word service is included.
- Network search opens the browser; it does not itself fetch, reason over, or summarize web content.
- The app-storage budget helper measures app files/cache but is not a hard OS-level quota and does not resize models. This project does not currently choose, download, quantize, or shrink an AI model based on phone capabilities.
- The optional accessibility bridge is powerful. Enable it only if you trust the app and want the explicitly requested typing capability.

## Next engineering steps for the full vision
1. Integrate a supported on-device inference runtime and model-selection screen; inspect RAM/storage/CPU first and let the user choose a model rather than silently changing model size.
2. Add local speech-to-text assets/runtime for guaranteed offline speech recognition and optional push-to-talk/wake word with visible microphone status.
3. Build retrieval over approved imported chats/documents, user-editable memory, and a transparent persona profile; do not claim this is model training.
4. Add a permissioned action broker with per-action confirmation for sending messages, purchases, deletion, or other consequential actions.
5. Test on actual devices and run Android unit/instrumentation tests before describing the APK as build-verified.
