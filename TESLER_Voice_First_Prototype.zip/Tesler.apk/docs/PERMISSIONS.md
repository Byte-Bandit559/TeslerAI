# Permission plan

Start with the minimum permissions needed by the implemented features. Add microphone,
notification listener, foreground service, or other permissions only when the associated
feature exists and has an appropriate user-facing explanation. Prefer Android document
picker APIs over broad file access. Review current Android requirements before release.
