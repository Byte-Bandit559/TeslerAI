# Feature status

## Present in this scaffold
- Native Android project structure and Gradle configuration
- Minimal TESLER chat shell
- Theme colors and manifest
- Module README files and starter contracts

## Not yet implemented
- Real local LLM inference / Quick Brain / Thinking Brain
- Offline speech recognition, wake word, and voice cloning
- Persistent database and semantic memory retrieval
- PDF/WhatsApp import and vector search
- Floating bubble and notification listener
- Device automation integrations and plugin runtime
- PC companion sync and self-update workflow

Do not describe a feature as working until it is implemented and tested on-device.
