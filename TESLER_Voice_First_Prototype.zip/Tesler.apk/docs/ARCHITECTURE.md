# TESLER Architecture

The project is organized into UI, domain, data, AI, and Android integration boundaries.
Keep UI code separate from inference and device actions. Device actions should be typed,
permission-checked, and confirmed when they have meaningful side effects.

The AI engine is an interface until a compatible local inference runtime and model assets
are selected and integrated.
