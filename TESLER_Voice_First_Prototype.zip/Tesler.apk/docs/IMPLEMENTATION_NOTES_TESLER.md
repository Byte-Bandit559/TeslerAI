# TESLER update notes (source package)

## Added in this revision
- `memory/LocalMemoryStore.kt`: app-local text memory with a rolling 21-day retention window, exact substring search, and manual clear. This is not semantic retrieval and does not train/fine-tune a model. Integrate it into the chat flow before calling it active product memory.
- `device/StorageBudget.kt`: helper measuring app `filesDir` and `cacheDir` against a 2 GiB ceiling. It is a measurement/admission helper, not an OS-enforced quota; every write/model import must call it, and other storage locations are not counted.
- `plugins/PluginFileLoader.kt`: reads bounded JSON plugin manifests from `filesDir/plugins`. It does not execute arbitrary code. This is intentionally a safe manifest discovery step, not a complete plugin runtime.
- `workspace/ChangeProposal.kt`: proposal structure for human-reviewed code changes. It does not apply patches.
- `plugins/example-greeting.json`: sample manifest.

## Important limitations
- No AI model weights or inference runtime are bundled; model weights cannot be synthesized merely by creating source files.
- The current app chat still uses canned/local rule-based responses.
- Existing Android TTS is output-only. Full offline speech recognition, wake-word listening and voice cloning are not implemented. Android speech recognition may rely on installed services/network and is not guaranteed offline.
- The new memory, storage, plugin, and change-proposal helpers are not yet wired into the UI/chat pipeline.
- The 2 GiB helper does not enforce a hard quota unless all file/model writes are routed through it.
- Self-editing must be staged: generate a diff, run tests/static checks, show the diff and risks, require explicit approval, back up, apply to a working copy, rerun checks, and support rollback. Never silently rewrite or execute its own code.
- No APK is provided. This remains an Android Studio source project and needs a real build/test run with compatible JDK/Android SDK/Gradle setup.

## Suggested integration order
1. Build the current app and fix compile errors.
2. Add a real on-device inference runtime and a licensed quantized model that fits device RAM/storage.
3. Wire LocalMemoryStore into chat with clear/export controls and automated 21-day expiry tests.
4. Route all imports/model storage through StorageBudget and add preflight checks.
5. Define a strict plugin action API with allowlisted capabilities and per-plugin approval.
6. Implement voice input with an explicitly verified offline engine if offline operation is mandatory.
7. Build a review-only patch workflow with automated tests and rollback before any code application.
