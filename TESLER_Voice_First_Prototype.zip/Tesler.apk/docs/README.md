# Project documentation

Architecture, feature status, and permission planning.
