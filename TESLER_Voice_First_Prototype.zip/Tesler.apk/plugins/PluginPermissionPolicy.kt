package com.tesler.ai.plugins

 /**
  * Plugin framework: starter interface.
  * TODO: implement and test this component before treating the feature as available.
  */
interface PluginPermissionPolicy {
    // Define a narrow, testable contract here as the feature is implemented.
}
