# Plugin framework

Plugin contracts and least-privilege permission model. Do not load untrusted arbitrary code.
