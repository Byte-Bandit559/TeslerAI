# Application settings

Typed settings contracts for UI, model selection, and privacy options.
