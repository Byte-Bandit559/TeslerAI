# TESLER

TESLER is a voice-first Android assistant prototype. This source revision adds tap-to-talk speech recognition, spoken responses through Android Text-to-Speech, local 21-day memory groundwork, basic app/Settings/music/web-search commands, a device overview, and an optional user-enabled Accessibility bridge for typing into a focused text field.

**Important:** this is still not a full conversational AI. No model weights or inference runtime are bundled; general conversation remains rule-based. Offline speech recognition and TTS depend on the voice/speech packages installed on the phone. TESLER does not clone the user's voice or train itself from chats. See `docs/VOICE_FIRST_CAPABILITIES.md` and `docs/IMPLEMENTATION_NOTES_TESLER.md` for details and limitations.

## Build
Open the `Tesla` folder in Android Studio with a compatible JDK and Android SDK, sync Gradle, then build and test the debug APK. This archive does not include a compiled APK. The project has not been compiled or device-tested in this environment.
