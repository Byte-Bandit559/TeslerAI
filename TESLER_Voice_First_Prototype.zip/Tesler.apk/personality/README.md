# Editable response personality

Stores style preferences separately from model weights. Example profile is provided in assets.
