# Tesla brand assets

- `tesler_T_master.png` is the generated black dripping/ribbon-style T on white background.
- Android launcher PNGs are copied into the app `res/mipmap-*` directories.
- The launcher is configured in `app/src/main/AndroidManifest.xml`.
