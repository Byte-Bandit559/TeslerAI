# Consent and retention

User controls for local data, retention, and optional integrations.
