package com.tesler.ai.privacy

 /**
  * Consent and retention: starter interface.
  * TODO: implement and test this component before treating the feature as available.
  */
interface ConsentManager {
    // Define a narrow, testable contract here as the feature is implemented.
}
