# Gradle wrapper

A standard Android project includes Gradle wrapper scripts and wrapper JAR here. This scaffold does not fabricate the wrapper JAR; generate it with Gradle or Android Studio in a build environment.
