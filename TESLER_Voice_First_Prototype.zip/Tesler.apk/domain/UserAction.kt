package com.tesler.ai.domain

 /**
  * Core domain types: starter interface.
  * TODO: implement and test this component before treating the feature as available.
  */
interface UserAction {
    // Define a narrow, testable contract here as the feature is implemented.
}
