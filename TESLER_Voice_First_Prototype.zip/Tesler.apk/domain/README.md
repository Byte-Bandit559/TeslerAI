# Core domain types

Framework-independent entities and use-case contracts.
