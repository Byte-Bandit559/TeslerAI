# AI engine

Model routing, inference adapters, prompt/context assembly, and output validation. Real model runtime and weights are not bundled.
