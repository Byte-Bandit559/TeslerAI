package com.tesler.ai.accessibility

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/** Optional, explicitly user-enabled bridge for typing into the currently focused editable field. */
class TeslerAccessibilityService : AccessibilityService() {
    override fun onServiceConnected() { super.onServiceConnected(); instance = this; serviceInfo = serviceInfo.apply { flags = flags or AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS } }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) { }
    override fun onInterrupt() { }
    override fun onDestroy() { if (instance === this) instance = null; super.onDestroy() }
    private fun typeText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val focus = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
        if (!focus.isEditable) { focus.recycle(); root.recycle(); return false }
        val args = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text) }
        val ok = focus.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        focus.recycle(); root.recycle(); return ok
    }
    companion object {
        @Volatile private var instance: TeslerAccessibilityService? = null
        fun typeIntoFocusedField(text: String): Boolean = instance?.typeText(text) ?: false
    }
}
