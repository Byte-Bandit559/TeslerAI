package com.tesler.ai.memory

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * Small local, time-aware memory store. Memories older than 21 days are pruned on access.
 * This is retrieval/storage, not model training or semantic search.
 */
class LocalMemoryStore(context: Context, private val now: () -> Long = { System.currentTimeMillis() }) {
    private val file = File(context.filesDir, "tesler_memory.json")
    private val retentionMs = 21L * 24 * 60 * 60 * 1000
    @Synchronized fun remember(text: String, tags: List<String> = emptyList()) {
        val value = text.trim(); if (value.isEmpty()) return
        val rows = readAndPrune()
        rows.put(JSONObject().put("text", value).put("tags", JSONArray(tags)).put("createdAt", now()))
        write(rows)
    }
    @Synchronized fun recent(limit: Int = 100): List<String> {
        val rows = readAndPrune(); val out = mutableListOf<String>()
        for (i in (rows.length()-1 downTo 0).take(limit.coerceAtLeast(0))) out += rows.getJSONObject(i).optString("text")
        return out
    }
    @Synchronized fun search(query: String, limit: Int = 20): List<String> {
        val q = query.trim().lowercase(); if (q.isEmpty()) return emptyList()
        return recent(1000).filter { it.lowercase().contains(q) }.take(limit.coerceAtLeast(0))
    }
    @Synchronized fun clear() { file.delete() }
    private fun readAndPrune(): JSONArray {
        val old = try { JSONArray(if (file.exists()) file.readText() else "[]") } catch (_: Exception) { JSONArray() }
        val kept = JSONArray(); val cutoff = now() - retentionMs
        for (i in 0 until old.length()) {
            val row = old.optJSONObject(i) ?: continue
            if (row.optLong("createdAt", 0L) >= cutoff) kept.put(row)
        }
        if (kept.length() != old.length()) write(kept)
        return kept
    }
    private fun write(rows: JSONArray) {
        file.parentFile?.mkdirs(); val tmp = File(file.parentFile, file.name + ".tmp")
        tmp.writeText(rows.toString()); if (!tmp.renameTo(file)) { file.writeText(rows.toString()); tmp.delete() }
    }
}
