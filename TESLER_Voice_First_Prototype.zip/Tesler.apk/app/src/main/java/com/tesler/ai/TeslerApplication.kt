package com.tesler.ai

import android.app.Application

class TeslerApplication : Application()
