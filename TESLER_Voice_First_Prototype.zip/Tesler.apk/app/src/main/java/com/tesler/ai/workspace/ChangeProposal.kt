package com.tesler.ai.workspace

/** Data model for human-approved self-improvement. This class does not modify or execute source code. */
data class ChangeProposal(
    val id: String,
    val summary: String,
    val targetRelativePath: String,
    val unifiedDiff: String,
    val checks: List<String>,
    val createdAtMillis: Long
)

enum class ProposalState { DRAFT, CHECKS_PASSED, AWAITING_USER_APPROVAL, APPROVED, REJECTED, APPLIED, ROLLED_BACK }
