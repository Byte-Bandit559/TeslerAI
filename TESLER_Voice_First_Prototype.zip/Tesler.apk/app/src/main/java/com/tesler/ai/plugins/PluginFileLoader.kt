package com.tesler.ai.plugins

import android.content.Context
import org.json.JSONObject
import java.io.File

/** Loads declarative JSON plugin manifests from filesDir/plugins. It deliberately does NOT execute
 * arbitrary Kotlin/JAR/APK code. A future runtime must validate capabilities and ask user approval.
 */
class PluginFileLoader(context: Context) {
    private val directory = File(context.filesDir, "plugins").apply { mkdirs() }
    data class Plugin(val id: String, val name: String, val version: String, val description: String, val actions: List<String>)
    fun loadManifests(): List<Plugin> = directory.listFiles()?.filter { it.isFile && it.extension.equals("json", true) }
        ?.mapNotNull { parse(it) } ?: emptyList()
    private fun parse(file: File): Plugin? = try {
        if (file.length() > 64 * 1024) return null
        val j = JSONObject(file.readText())
        val id = j.optString("id"); val name = j.optString("name")
        val actionsJson = j.optJSONArray("actions") ?: return null
        if (!id.matches(Regex("[a-zA-Z0-9._-]{1,64}")) || name.isBlank() || actionsJson.length() > 32) return null
        val actions = (0 until actionsJson.length()).map { actionsJson.optString(it) }.filter { it.matches(Regex("[a-zA-Z0-9._-]{1,64}")) }
        Plugin(id, name, j.optString("version", "0.1.0"), j.optString("description"), actions)
    } catch (_: Exception) { null }
}
