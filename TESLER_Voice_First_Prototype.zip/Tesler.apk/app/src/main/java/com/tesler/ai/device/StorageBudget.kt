package com.tesler.ai.device

import android.content.Context
import java.io.File

/** App-managed storage budget. It measures files under app files/cache and reports remaining bytes.
 * Android OS data, shared storage and model files placed elsewhere are outside this measurement.
 */
class StorageBudget(context: Context, private val maxBytes: Long = 2L * 1024 * 1024 * 1024) {
    private val roots = listOfNotNull(context.filesDir, context.cacheDir)
    fun usedBytes(): Long = roots.sumOf { sizeOf(it) }
    fun remainingBytes(): Long = (maxBytes - usedBytes()).coerceAtLeast(0)
    fun canAllocate(bytes: Long): Boolean = bytes >= 0 && bytes <= remainingBytes()
    fun limitBytes(): Long = maxBytes
    private fun sizeOf(file: File): Long = try {
        if (!file.exists()) 0L else if (file.isFile) file.length() else file.listFiles()?.sumOf { sizeOf(it) } ?: 0L
    } catch (_: SecurityException) { 0L }
}
