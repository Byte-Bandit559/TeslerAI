package com.tesler.ai

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.net.Uri
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.tesler.ai.accessibility.TeslerAccessibilityService
import com.tesler.ai.device.StorageBudget
import com.tesler.ai.memory.LocalMemoryStore
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.Locale
import kotlin.math.roundToInt

/** Voice-first TESLER prototype. Uses Android speech services and rule-based local routing;
 * it is not yet backed by a large language model. */
class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var transcript: LinearLayout
    private lateinit var input: EditText
    private lateinit var status: TextView
    private lateinit var prefs: android.content.SharedPreferences
    private lateinit var memory: LocalMemoryStore
    private var tts: TextToSpeech? = null
    private var recognizer: SpeechRecognizer? = null
    private val history = JSONArray()
    private val pickFileCode = 4102
    private val micPermissionCode = 4103

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("tesler_local", MODE_PRIVATE)
        memory = LocalMemoryStore(this)
        loadHistory()
        tts = TextToSpeech(this, this)
        if (SpeechRecognizer.isRecognitionAvailable(this)) recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        window.statusBarColor = android.graphics.Color.rgb(18, 25, 36)
        window.navigationBarColor = android.graphics.Color.rgb(18, 25, 36)
        buildVoiceUi()
        if (history.length() == 0) {
            val hello = "Yo bro, I'm TESLER. Tap the mic and talk to me. I can listen through Android speech recognition, speak replies, open apps and settings, and remember things locally. My full offline reasoning brain is not connected yet."
            addMessage("TESLER", hello, speak = true)
        } else for (i in 0 until history.length()) {
            val row = history.optJSONObject(i) ?: continue
            drawMessage(row.optString("sender"), row.optString("body"))
        }
        status.text = "Voice buddy • ${if (recognizer != null) "speech recognition available" else "speech recognition unavailable"}"
    }

    private fun buildVoiceUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(16, 12, 16, 12); setBackgroundColor(0xFF121924.toInt()) }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(TextView(this).apply { text = "TESLER"; textSize = 27f; setTextColor(-1) }, LinearLayout.LayoutParams(0, 54, 1f))
        header.addView(Button(this).apply { text = "Device"; setOnClickListener { say(deviceOverview()) } })
        header.addView(Button(this).apply { text = "Import chats"; setOnClickListener { openTextFilePicker() } })
        root.addView(header)
        status = TextView(this).apply { text = "Tap the mic to talk"; textSize = 13f; setTextColor(0xFF9FB4CD.toInt()); setPadding(4, 3, 4, 10) }
        root.addView(status)
        val scroll = ScrollView(this)
        transcript = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(transcript)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        input = EditText(this).apply { hint = "Or type here…"; setHintTextColor(0xFF9AA6B2.toInt()); setTextColor(-1); setPadding(12, 8, 12, 8); setBackgroundColor(0xFF263244.toInt()) }
        root.addView(input, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT))
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        row.addView(Button(this).apply { text = "🎙 TALK"; textSize = 17f; setOnClickListener { startListening() } }, LinearLayout.LayoutParams(0, 62, 1.3f))
        row.addView(Button(this).apply { text = "Send"; setOnClickListener { val s = input.text.toString().trim(); input.setText(""); if (s.isNotEmpty()) handleUserText(s) } }, LinearLayout.LayoutParams(0, 62, 1f))
        row.addView(Button(this).apply { text = "Stop"; setOnClickListener { recognizer?.cancel(); tts?.stop(); status.text = "Stopped" } }, LinearLayout.LayoutParams(0, 62, 0.8f))
        root.addView(row)
        val bottom = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        bottom.addView(Button(this).apply { text = "Accessibility typing"; setOnClickListener { startActivity(Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS)) } }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        bottom.addView(Button(this).apply { text = "Export chat"; setOnClickListener { exportHistoryText() } }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(bottom)
        setContentView(root)
    }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale.getDefault())
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) tts?.language = Locale.US
        }
    }

    private fun startListening() {
        if (recognizer == null) { say("Speech recognition is not available on this phone. You can still type to me."); return }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), micPermissionCode); return
        }
        tts?.stop()
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Talk to TESLER")
        }
        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { status.text = "Listening… speak naturally" }
            override fun onBeginningOfSpeech() { status.text = "I'm listening" }
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { status.text = "Thinking…" }
            override fun onError(error: Int) { status.text = "Didn't catch that — tap TALK and try again" }
            override fun onResults(results: Bundle?) {
                val spoken = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                if (spoken.isNotBlank()) handleUserText(spoken) else status.text = "Didn't catch that"
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        try { recognizer?.startListening(intent) } catch (_: Exception) { status.text = "Couldn't start microphone" }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == micPermissionCode && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) startListening()
        else if (requestCode == micPermissionCode) say("I need microphone permission to listen. You can still type to me.")
    }

    private fun handleUserText(text: String) {
        addMessage("You", text)
        memory.remember("User said: $text", listOf("conversation"))
        val answer = routeCommand(text)
        addMessage("TESLER", answer, speak = true)
    }

    private fun routeCommand(text: String): String {
        val m = text.trim().lowercase(Locale.ROOT)
        when {
            m == "help" || m.contains("what can you do") -> return "Talk to me, ask me to open an app, open Android settings, show phone info, play music, search the web when connected, or say 'remember that…'. Say 'type …' to type into a focused field after enabling TESLER's optional Accessibility service. I'm still a prototype, not a full LLM yet."
            m.startsWith("remember that ") || m.startsWith("remember ") -> { val fact = text.substringAfter(' ').substringAfter(' ', text.substringAfter(' ')).trim(); memory.remember(fact, listOf("user-fact")); return "Got you, bro. I'll keep that in local memory for up to 21 days, then it expires. You can clear app data to erase it sooner." }
            m.contains("what do you remember") || m.contains("recall") -> { val hits = memory.recent(8); return if (hits.isEmpty()) "My local memory is empty for now, bro." else "Here's what I've kept locally:\n" + hits.joinToString("\n• ", prefix = "• ") }
            m.contains("device info") || m.contains("phone specs") || m.contains("system overview") || m.contains("phone overview") || m.contains("what phone") -> return deviceOverview()
            m.contains("open settings") || m == "settings" -> { startActivity(Intent(android.provider.Settings.ACTION_SETTINGS)); return "Opening Android settings, bro." }
            m.contains("open wi-fi settings") || m.contains("open wifi settings") || m.contains("wifi settings") -> { startActivity(Intent(android.provider.Settings.ACTION_WIFI_SETTINGS)); return "Opening Wi-Fi settings." }
            m.contains("bluetooth settings") -> { startActivity(Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS)); return "Opening Bluetooth settings." }
            m.contains("battery settings") -> { startActivity(Intent(android.provider.Settings.ACTION_BATTERY_SAVER_SETTINGS)); return "Opening battery settings." }
            m.contains("accessibility settings") -> { startActivity(Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS)); return "Opening Accessibility settings. Enable TESLER only if you want voice-controlled typing and UI actions." }
            m.startsWith("type ") -> { val payload = text.substringAfter(' ').trim(); return if (TeslerAccessibilityService.typeIntoFocusedField(payload)) "Done, bro. I sent that text to the focused field." else "I can't type into other apps yet. Open Accessibility settings and enable TESLER's service, then focus a text field and try again." }
            m.contains("play music") || m.contains("open music") -> { val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_MUSIC); if (i.resolveActivity(packageManager) != null) startActivity(i) else { val search = Intent(Intent.ACTION_VIEW, Uri.parse("https://music.youtube.com")); startActivity(search) }; return "Opening your music app, bro." }
            m.startsWith("search the web for ") || m.startsWith("google ") || m.startsWith("search for ") -> { if (!hasInternet()) return "Looks like you are offline, bro. We can still chat locally, but web search needs an internet connection."; val q = when { m.startsWith("search the web for ") -> text.substringAfter("for "); m.startsWith("search for ") -> text.substringAfter("search for "); else -> text.substringAfter(' ') }; startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q)))); return "Opening a web search. Internet access depends on your connection." }
            m.startsWith("open ") -> { val target = text.substringAfter(' ').trim(); if (openApp(target)) return "Opening $target, bro." }
        }
        if (m.contains("hello") || m.startsWith("hey") || m.startsWith("yo") || m.contains("what's up")) return "Yo bro 😄 I'm here. What's on your mind?"
        if (m.contains("who am i") || m.contains("my style")) return "I'm starting to pick up phrases you use from our chats, but right now I only store and retrieve local memories. I don't train a model or clone your voice yet."
        if (m.contains("time")) return "It's ${java.text.SimpleDateFormat("h:mm a", Locale.getDefault()).format(java.util.Date())}, bro."
        val matching = memory.search(text, 2)
        return if (matching.isNotEmpty()) "I don't have my full reasoning model connected yet, bro, but I found something related in memory: ${matching.first()}" else "I hear you, bro. I can talk with you using this starter voice setup, but proper open-ended conversation needs an offline language model to be connected. I'll keep this chat locally so the future brain can use it."
    }

    private fun openApp(query: String): Boolean {
        val pm = packageManager
        val apps = try { pm.getInstalledApplications(PackageManager.GET_META_DATA) } catch (_: Exception) { return false }
        val found = apps.firstOrNull { app ->
            val label = pm.getApplicationLabel(app).toString()
            label.equals(query, true) || label.contains(query, true) || query.contains(label, true) && label.length > 2
        } ?: return false
        val launch = pm.getLaunchIntentForPackage(found.packageName) ?: return false
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try { startActivity(launch); true } catch (_: Exception) { false }
    }

    private fun deviceOverview(): String {
        val am = getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager
        val mi = android.app.ActivityManager.MemoryInfo(); am.getMemoryInfo(mi)
        val battery = getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val level = battery.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        val storage = StorageBudget(this)
        val totalRam = mi.totalMem / (1024L * 1024L)
        val availRam = mi.availMem / (1024L * 1024L)
        val usedMb = storage.usedBytes() / (1024L * 1024L)
        val networkState = if (hasInternet()) "internet available" else "offline / no validated internet"
        val limitMb = storage.limitBytes() / (1024L * 1024L)
        return "Phone overview, bro: Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT}); device ${Build.MANUFACTURER} ${Build.MODEL}; RAM ${availRam} MB free of ${totalRam} MB; battery ${if (level >= 0) "$level%" else "unknown"}; app-managed files/cache ${usedMb} MB of a ${limitMb} MB budget; network: $networkState. TESLER can inspect these basic stats, but it cannot read or change every protected system setting."
    }


    private fun hasInternet(): Boolean {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(network) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    }

    private fun addMessage(sender: String, body: String, speak: Boolean = false) {
        val item = JSONObject().put("sender", sender).put("body", body).put("time", System.currentTimeMillis())
        history.put(item)
        while (history.length() > 500) history.remove(0)
        prefs.edit().putString("history", history.toString()).apply()
        drawMessage(sender, body)
        if (speak && tts != null) tts?.speak(body, TextToSpeech.QUEUE_FLUSH, null, "tesler-${System.currentTimeMillis()}")
    }

    private fun say(text: String) { addMessage("TESLER", text, speak = true) }
    private fun drawMessage(sender: String, body: String) {
        val view = TextView(this).apply { text = "$sender\n$body"; textSize = 15f; setTextColor(-1); setPadding(14, 12, 14, 12); setBackgroundColor(if (sender == "You") 0xFF254B55.toInt() else 0xFF202D3D.toInt()) }
        val params = LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT); params.setMargins(0, 6, 0, 6); transcript.addView(view, params)
    }

    private fun loadHistory() {
        val saved = getSharedPreferences("tesler_local", MODE_PRIVATE).getString("history", "[]") ?: "[]"
        try { val parsed = JSONArray(saved); for (i in 0 until parsed.length()) history.put(parsed.getJSONObject(i)) } catch (_: Exception) { }
    }
    private fun openTextFilePicker() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "text/plain" }
        startActivityForResult(i, pickFileCode)
    }
    @Deprecated("Use Activity Result APIs in production")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != pickFileCode || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        try {
            val text = contentResolver.openInputStream(uri)?.use { stream -> BufferedReader(InputStreamReader(stream, Charsets.UTF_8)).readText() } ?: ""
            val clipped = text.take(6000)
            memory.remember("Imported chat/document excerpt:\n$clipped", listOf("imported-chat"))
            say("Imported a local text excerpt into memory, bro. It is searchable storage, not model training. Here's a preview: ${clipped.take(800)}")
        } catch (e: Exception) { Toast.makeText(this, "Could not read that file: ${e.message}", Toast.LENGTH_LONG).show() }
    }
    private fun exportHistoryText() {
        val text = buildString { for (i in 0 until history.length()) { val row = history.optJSONObject(i) ?: continue; append(row.optString("sender")).append(": ").append(row.optString("body")).append("\n\n") } }
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_SUBJECT, "TESLER chat export"); putExtra(Intent.EXTRA_TEXT, text) }, "Export TESLER chat"))
    }
    override fun onDestroy() { recognizer?.destroy(); tts?.stop(); tts?.shutdown(); super.onDestroy() }
}
