# Tesla app icon

The generated black liquid/ribbon-style T on a white background has already been installed as:
- `mipmap-mdpi/ic_launcher.png`
- `mipmap-hdpi/ic_launcher.png`
- `mipmap-xhdpi/ic_launcher.png`
- `mipmap-xxhdpi/ic_launcher.png`
- `mipmap-xxxhdpi/ic_launcher.png`
- matching `ic_launcher_round.png` variants
- adaptive icon XML in `mipmap-anydpi-v26/`
- foreground assets in density-specific mipmap folders

The original 1024x1024 master image is at `branding/tesler_T_master.png`.
The Android manifest references `@mipmap/ic_launcher` and `@mipmap/ic_launcher_round`.
The application label is `Tesla`.

The generated art is a glossy black T with a white background. Inspect the icon on the target Samsung launcher after building because Android launchers crop adaptive icons to device-specific shapes.
