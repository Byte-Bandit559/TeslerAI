# TESLER test plan

- Compile and lint the Android project with the intended Android SDK.
- Test app startup, chat input, rotation, and process recreation.
- Test data persistence after a force-stop and reboot once storage is implemented.
- Test permission denial and revocation paths.
- Test offline behavior with network disabled.
- Profile memory, CPU, thermal behavior, and battery use on the target Samsung phone.
- Verify model loading, failure handling, and model removal once a real model is integrated.
- Review APK contents and signing before distribution.
