# File import and export

Use Android's document picker/scoped storage. Import only files selected or otherwise legitimately accessible.
