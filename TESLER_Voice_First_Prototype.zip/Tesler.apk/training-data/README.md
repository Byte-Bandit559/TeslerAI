# TESLER local knowledge files

## Where to put the six WhatsApp exports
Put the six exported `.txt` files in `training-data/whatsapp-exports/` in the source project.

Example:
- `chat_01.txt`
- `chat_02.txt`
- `chat_03.txt`
- `chat_04.txt`
- `chat_05.txt`
- `chat_06.txt`

Do not include media files unless you specifically want to build a media importer. Remove or redact passwords, bank details, recovery codes, and private information you do not want indexed.

## Important: these are not training data in the model-training sense
The exports are personal knowledge sources. A future TESLER importer should parse them, chunk the messages, index them locally, and retrieve relevant passages at question time. They do not change model weights and do not automatically train a model.

## On the phone
Files placed in this source folder do not automatically appear on the installed app. The user must either:
1. select the `.txt` files through TESLER's Import chat picker (current scaffold supports a text preview), or
2. implement/copy a controlled app-private import process during development.

The current starter app only imports a text preview into the conversation. Persistent indexing, semantic search, and full WhatsApp parsing are not implemented yet.
