Place additional user-selected text documents here during development. This directory is not automatically accessible to the installed app.
