# Document knowledge and retrieval

Document ingestion and retrieval interfaces. Format-specific parsers and embedding model integration remain to be implemented.
