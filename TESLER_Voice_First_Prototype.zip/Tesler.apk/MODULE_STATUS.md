# Module implementation status

| Module | Status in this archive |
|---|---|
| `app/` | Basic native chat shell implemented |
| `ai/` | Starter interfaces only; no model inference |
| `voice/` | Module contracts only; app shell has basic Android TTS |
| `memory/` | Module contracts only; app shell saves chat history locally |
| `knowledge/` | Starter contracts only |
| `actions/` | Starter contracts only |
| `device/` | Starter contracts only |
| `notifications/` | Starter contracts only |
| `files/` | Starter contracts; app shell has text-picker preview |
| `plugins/` | Contracts only |
| `personality/` | Starter contracts and sample JSON |
| `privacy/`, `security/` | Planning/contracts only |
| `settings/` | Contracts only |
| `automation/` | Contracts only |
| `workspace/` | Contracts only |
| `sync/` | Contracts only |
| `data/` | Contracts only; chat shell uses SharedPreferences |
| `domain/`, `ui/`, `navigation/`, `common/` | Starter scaffolding |
| `ai-models/` | No model weights included |
| `tools/`, `docs/`, `tests/` | Documentation/test plans |
