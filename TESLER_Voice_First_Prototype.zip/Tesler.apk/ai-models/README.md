# TESLER local AI models

No model weights are included. Model weights cannot be truthfully “generated” from application source code: choose a real, licensed model and compatible Android inference runtime, then distribute/import the weights separately. Keep the combined model and app-managed data within the 2 GiB budget. Validate SHA-256, license, architecture, quantization, memory needs and device compatibility before loading.

A model index is metadata only; it is not a model. Until inference runtime and weights are integrated and device-tested, TESLER uses the existing local rule-based placeholder responses.
