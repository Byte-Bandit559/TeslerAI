package com.tesler.ai.sync

 /**
  * Future local device sync: starter interface.
  * TODO: implement and test this component before treating the feature as available.
  */
interface SyncManager {
    // Define a narrow, testable contract here as the feature is implemented.
}
