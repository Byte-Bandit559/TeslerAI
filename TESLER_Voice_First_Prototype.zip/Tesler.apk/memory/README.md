# Conversation and personal memory

Local memory contracts, user-approved facts, retention, summaries, and deletion controls.
