package com.tesler.ai.memory

 /**
  * Conversation and personal memory: starter interface.
  * TODO: implement and test this component before treating the feature as available.
  */
interface MemoryPolicy {
    // Define a narrow, testable contract here as the feature is implemented.
}
