# Changelog\n\n## Unreleased\n- Initial TESLER project scaffold.\n
## Voice-first prototype revision
- Replaced the chat-first shell with a tap-to-talk voice-first interface, spoken responses, and typed fallback.
- Added simple spoken command routing for app launch, selected Android settings, device overview, music apps, browser search, local memory recall, and optional Accessibility-based typing.
- Added microphone permission and a manually enabled Accessibility Service declaration.
- Documented offline speech/provider limitations and the absence of a connected LLM/model runtime.
