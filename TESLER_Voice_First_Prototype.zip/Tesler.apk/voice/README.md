# Voice input and output

Speech input/output abstractions. Offline recognition and always-on wake-word detection require a compatible engine and careful Android service/permission work.
