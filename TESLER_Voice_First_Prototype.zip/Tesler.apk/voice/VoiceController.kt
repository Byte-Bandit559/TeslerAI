package com.tesler.ai.voice

 /**
  * Voice input and output: starter interface.
  * TODO: implement and test this component before treating the feature as available.
  */
interface VoiceController {
    // Define a narrow, testable contract here as the feature is implemented.
}
