# Controlled improvement workflow

Proposals, diffs, tests, and user approval. An installed app cannot silently replace itself.
