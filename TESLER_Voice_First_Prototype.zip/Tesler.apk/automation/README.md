# Scheduled tasks and habits

Scheduled work and habit tracking; background execution is subject to Android restrictions.
