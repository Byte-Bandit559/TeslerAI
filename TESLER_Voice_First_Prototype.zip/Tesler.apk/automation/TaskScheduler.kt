package com.tesler.ai.automation

 /**
  * Scheduled tasks and habits: starter interface.
  * TODO: implement and test this component before treating the feature as available.
  */
interface TaskScheduler {
    // Define a narrow, testable contract here as the feature is implemented.
}
