# Device capability and resource adaptation

Hardware profile, memory/storage budget, and non-destructive cleanup recommendations.
