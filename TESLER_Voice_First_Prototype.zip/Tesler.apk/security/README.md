# Security primitives and checks

Security boundaries and validation interfaces; encryption implementations must be reviewed and tested.
