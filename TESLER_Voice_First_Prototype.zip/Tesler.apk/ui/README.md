# User interface

UI design and screen layer. The initial native shell is implemented in app/MainActivity.kt.
