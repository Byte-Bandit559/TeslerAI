package com.tesler.ai.data

 /**
  * Persistence layer: starter interface.
  * TODO: implement and test this component before treating the feature as available.
  */
interface PreferencesStore {
    // Define a narrow, testable contract here as the feature is implemented.
}
