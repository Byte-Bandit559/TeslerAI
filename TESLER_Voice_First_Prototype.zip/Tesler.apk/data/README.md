# Persistence layer

Data contracts and database planning. Select and implement Room or another persistent storage solution.
